function initClouds(){
    for(var i=0; i<10; i++){
        var x = random(-800, 3500);
        var y = random(20, 100);
        var w = random(65, 80);
        var s = random(0.4, 0.6);
        var cloud = {pos_x: x, pos_y: y, width:w, speed: s};
        clouds.push(cloud);
    }
}

function initCactuses(){
    for(var i=0; i<7; i++){
        var x = random(-200, 3500);
        var y = floorPos_y-102;
        var cactus = {pos_x: x, pos_y: y};
        if(isCactusOnCanyon(cactus)==false){
            cactuses.push(cactus);
        }
    }
}

function initMountains(){
    for(var i=0; i<3; i++){
        var x = random(-200, 3500);
        var w = random(250,400);
        var h = random(220,350);
        var mountain = {pos_x: x, width: w, height: h}
        if(isMountainOnCanyon(mountain)==false){
            mountains.push(mountain);
        }
    }
}

function initCanyons(){
    for(var i=0; i<3; i++){
        var x = random(300, 3500);
        var canyon = {pos_x: x, width: 100};
        canyons.push(canyon);
    }
}

function initPlatforms(){
    var p1 = createPlatform(random(300,940),floorPos_y-random(92,120), 100);
    platforms.push(p1);
    
    var p2 = createPlatform(random(940,1580),floorPos_y-random(92,120), 100);
    platforms.push(p2);
    
    var p3 = createPlatform(random(1580,2220),floorPos_y-random(92,120), 100);
    platforms.push(p3);
    
    var p4 = createPlatform(random(2220,2860),floorPos_y-random(92,120), 100);
    platforms.push(p4);
    
    var p5 = createPlatform(random(2860,3500),floorPos_y-random(92,120), 100);
    platforms.push(p5);
}

function initEnemies(){
    var e1 = new Enemy(random(300,940), floorPos_y-10, 100);
    enemies.push(e1);
    var e2 = new Enemy(random(940,1580), floorPos_y-10, 100);
    enemies.push(e2);
    var e3 = new Enemy(random(1580,2220), floorPos_y-10, 100);
    enemies.push(e3);
    var e4 = new Enemy(random(2220,2860), floorPos_y-10, 100);
    enemies.push(e4);
    var e5 = new Enemy(random(2860,3500), floorPos_y-10, 100);
    enemies.push(e5);
}

function initFire(){    
    var emitter1 = new Emitter(random(300,940),floorPos_y,0,-1,10,color(255,0,0));
    emitter1.startEmitter(200,75);
    emitters.push(emitter1);
    
    var emitter2 = new Emitter(random(940,1580),floorPos_y,0,-1,10,color(255,0,0));
    emitter2.startEmitter(200,75);
    emitters.push(emitter2);
    
    var emitter3 = new Emitter(random(1580,2220),floorPos_y,0,-1,10,color(255,0,0));
    emitter3.startEmitter(200,75);
    emitters.push(emitter3);
    
    var emitter4 = new Emitter(random(2220,2860),floorPos_y,0,-1,10,color(255,0,0));
    emitter4.startEmitter(200,75);
    emitters.push(emitter4);
    
    var emitter5 = new Emitter(random(2860,3500),floorPos_y,0,-1,10,color(255,0,0));
    emitter5.startEmitter(200,75);
    emitters.push(emitter5);
}

function initCoins(){
    var total_coins = 30;
    
    while(coins.length < total_coins){
        var x = random(300, 3500);
        var c = {pos_x: x, pos_y: floorPos_y-30, size: 30, isFound: false}
        
        for(var i=0; i<30; i++){
            var x = random(300, 3500);
            var c = {pos_x: x, pos_y: floorPos_y-30, size: 30, isFound: false}
            
            if(isCoinOnCanyon(c)==false){
                coins.push(c);
            }
        }
        console.log(coins.length);
    }
}

function initLifeTokens(){
    var total_lifeTokens = 2;
    
    while(lifeTokens.length < total_lifeTokens){
        var x = random(300, 3500);
        var c = {pos_x: x, pos_y: floorPos_y-30, size: 30, isFound: false}
        
        for(var i=0; i<2; i++){
            var x = random(300, 3500);
            var c = {pos_x: x, pos_y: floorPos_y-30, size: 30, isFound: false}
            
            if(isLifeTokenOnCanyon(c)==false){
                lifeTokens.push(c);
            }
        }
        console.log(lifeTokens.length);
    }
}