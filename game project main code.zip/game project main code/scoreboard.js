function drawGameScore(){
    fill(0);
    textSize(30);
    text("Score:"+game_score,10,30);
    
    text("Lives:"+lives,920, 30);
}

function drawLifeCounter(){
    stroke(0);
    strokeWeight(3);
    fill(255,0,0);
    for(var i=0;i<lives;i++){
        ellipse(40*i+840,60,30,30);
    }
}