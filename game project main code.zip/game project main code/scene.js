function drawSky(){
    background(135,206,250);
    }

function drawGround()
{
    noStroke();
	fill(225,192,123);
	rect(0, floorPos_y, width, height);
}

function drawClouds(){
    fill(255);
    for(var i in clouds){
        drawCloud(clouds[i]);
    }
}

function drawCloud(t_cloud){
    ellipse(t_cloud.pos_x,t_cloud.pos_y,t_cloud.width,t_cloud.width*0.53);
    ellipse(t_cloud.pos_x-20,t_cloud.pos_y+12,t_cloud.width,t_cloud.width*0.53);
    ellipse(t_cloud.pos_x+25,t_cloud.pos_y+12,t_cloud.width+5,t_cloud.width*0.53);
}

function drawCanyons(){
    /*fill(135,206,250);*/
    fill(50);
    for(var i=0;i<canyons.length;i++){
        var canyon = canyons[i];
        drawCanyon(canyon);
    }
}

function drawCanyon(t_Canyon){
    rect(t_Canyon.pos_x,floorPos_y,t_Canyon.width,height-floorPos_y);
}

function drawMountains(){
    for(var i=0;i<mountains.length;i++){
        var mountain = mountains[i];
        drawMountain(mountain);
    }
}

function drawMountain(t_Mountain){
    //main mountain
    fill(205,133,63);
    triangle(t_Mountain.pos_x-t_Mountain.width/2,
             floorPos_y,
             t_Mountain.pos_x,
             floorPos_y-t_Mountain.height,
             t_Mountain.pos_x+t_Mountain.width/2,
             floorPos_y);
    fill (0,0,0,50);
    triangle(t_Mountain.pos_x+t_Mountain.width/2,
             floorPos_y,
             t_Mountain.pos_x,
             floorPos_y-t_Mountain.height,
             t_Mountain.pos_x+t_Mountain.width/4,
             floorPos_y);
    
    //secondary mountain
    fill(185,113,43);
    triangle(t_Mountain.pos_x/2-t_Mountain.width/4,
             floorPos_y,
             t_Mountain.pos_x/2,
             floorPos_y-t_Mountain.height/2,
             t_Mountain.pos_x/2+t_Mountain.width/4,
             floorPos_y);
    fill (0,0,0,50);
    triangle(t_Mountain.pos_x/2+t_Mountain.width/4,
             floorPos_y,
             t_Mountain.pos_x/2,
             floorPos_y-t_Mountain.height/2,
             t_Mountain.pos_x/2+t_Mountain.width/8,
             floorPos_y);
}

function drawCactuses(){
    fill(0,145,0);
    for(var i=0;i<cactuses.length;i++){
        var cactus = cactuses[i];
        drawCactus(cactus);
    }
}

function drawCactus(t_Cactus){
    rect(t_Cactus.pos_x,t_Cactus.pos_y,35,102,30,30,0,0);
    rect(t_Cactus.pos_x+35,t_Cactus.pos_y+60,25,15,0,0,30,0);
    rect(t_Cactus.pos_x+45,t_Cactus.pos_y+25,15,35,30,30,0,0);
}

function createPlatform(x,y,length){
    var p = {
        x:x,
        y:y,
        length:length,
        draw: function(){
            fill(225,133,70);
            stroke(0);
            strokeWeight(2);
            rect(this.x, this.y, this.length,20,5);
            noStroke(); //remove stroke for other items
        },
        checkContact: function(gc_x, gc_y){
            var c1 = gc_x+20>this.x;
            var c2 = gc_x<this.x+20+this.length;
            
            if(c1 && c2){
                //check for y-axis
                var d = this.y - gc_y;
                if(d>=0 && d<1){
                    return true;
                }
            }
            return false;
        }
    }
    return p;
}

function drawPlatforms(){
    for(i in platforms){
        var platform = platforms[i];
        platform.draw();
    }
}

function drawFire(){
    for(var i=0;i<emitters.length;i++){
        var emitter = emitters[i];
        emitter.drawAndUpdateParticles();
    }
}

function drawCoins(){
    for(var i=0;i<coins.length;i++){
        if(coins[i].isFound==false){
            drawCoin(coins[i]);
        }
    }
}

function drawCoin(t_Coin){
    stroke(180,165,0);
    strokeWeight(3);
    fill(255,215,0);
    ellipse(t_Coin.pos_x,t_Coin.pos_y,t_Coin.size,t_Coin.size);
}

function drawLifeTokens(){
    for(var i=0;i<lifeTokens.length;i++){
        if(lifeTokens[i].isFound==false){
            drawLifeToken(lifeTokens[i]);
        }
    }
}

function drawLifeToken(t_LifeToken){
    stroke(0);
    strokeWeight(3);
    fill(255,0,0);
    ellipse(t_LifeToken.pos_x,t_LifeToken.pos_y,t_LifeToken.size,t_LifeToken.size);
}

function Enemy (x,y,range){
    this.x = x;
    this.y = y;
    this.range = range;
    
    this.currentX = x;
    this.inc = 1;
    
    this.update = function(){
        this.currentX += this.inc;
        if(this.currentX>this.x+this.range){
            this.inc = -1;
        }else if(this.currentX<this.x){
            this.inc = 1;
        }
    }
    this.draw = function(){
        this.update();
        fill(130,20,130);
        ellipse(this.currentX,this.y,20,20);
    }
    this.checkContact = function(gc_x,gc_y){
        var d = dist(this.currentX, this.y,gc_x,gc_y);
        if(d<20){
            return true;
        }else{
            return false;
        }
    }
}

function drawEnemies(){
    for(i in enemies){
        var enemy = enemies[i];
        enemy.draw();
    }
}


function drawFlagpole(){
    noStroke();
    fill(125);
    rect(flagpole.pos_x,floorPos_y-flagpole.pole_height,15,flagpole.pole_height);
    
    //raise flag when reached
    fill(0);
    if(flagpole.isReached==true){
        rect(flagpole.pos_x,floorPos_y-flagpole.pole_height,flagpole.flag_width,flagpole.flag_height);
    }else{
        rect(flagpole.pos_x,floorPos_y-flagpole.flag_height,flagpole.flag_width,flagpole.flag_height);
    }
}

function drawGameOver(){
    fill(0);
    textSize(70);
    text("GAME OVER",300,height/2-100);
    
    textSize(40);
    if(lives>0){
        /*text("YOU WIN! :)",300,height/2);*/
        text("Level complete! Press space to continue",200,height/2);
    }else if(lives<1){
        /*text("You lose... :(",300,height/2);*/
        text("You lose... Press space to continue",200,height/2);
    }
}