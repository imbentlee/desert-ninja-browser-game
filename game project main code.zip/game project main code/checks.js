function isCactusOnCanyon(t_cactus){
    var onCanyon = false;
    for(i in canyons){
        var canyon = canyons[i];
        var x1_limit = canyon.pos_x - t_cactus.pos_x;
        var x2_limit = canyon.pos_x + canyon.width;
        if(t_cactus.pos_x>x1_limit && t_cactus.pos_x<x2_limit){
            onCanyon = true;
            break; //to exit the for loop
        }
    }
    return onCanyon;
}

function isMountainOnCanyon(t_mountain){
    var onCanyon = false;
    for(i in canyons){
        var canyon = canyons[i];
        var x1_limit = canyon.pos_x - t_mountain.pos_x;
        var x2_limit = canyon.pos_x + canyon.width;
        if(t_mountain.pos_x>x1_limit && t_mountain.pos_x<x2_limit){
            onCanyon = true;
            break; //to exit the for loop
        }
    }
    return onCanyon;
}

function isCoinOnCanyon(t_c){
    var onCanyon = false;
    for(i in canyons){
        var canyon = canyons[i];
        var x1_limit = canyon.pos_x - t_c.size;
        var x2_limit = canyon.pos_x + canyon.width;
        if(t_c.pos_x>x1_limit && t_c.pos_x<x2_limit){
            onCanyon = true;
            break; //to exit the for loop
        }
    }
    return onCanyon;
}

function isLifeTokenOnCanyon(t_c){
    var onCanyon = false;
    for(i in canyons){
        var canyon = canyons[i];
        var x1_limit = canyon.pos_x - t_c.size;
        var x2_limit = canyon.pos_x + canyon.width;
        if(t_c.pos_x>x1_limit && t_c.pos_x<x2_limit){
            onCanyon = true;
            break; //to exit the for loop
        }
    }
    return onCanyon;
}

function checkIfGameCharIsOverCanyons(){
        for(var i=0;i<canyons.length;i++){
            var canyon = canyons[i];
            checkIfGameCharIsOverCanyon(canyon);
        }
    }
function checkIfGameCharIsOverCanyon(canyon){
    
    if(checkIsGameOver()){
        return;
    }
        //console.log(gameChar_x);
        console.log(gameChar_world_x);
        
        var cond1 = gameChar_y == floorPos_y;                                          //check if character is on the floor
        
        var cond2 = gameChar_world_x - gameChar_width/2>(canyon.pos_x);                //check if charcter is within left boundary of canyon
        
        var cond3 = gameChar_world_x + gameChar_width/2<(canyon.pos_x+canyon.width);   //check if charcter is within right boundary of canyon
        
        if(cond1 && cond2 && cond3){
            isPlummeting=true;          //if all 3 conditions are met, character will plummet
            lives--;
            fallSound.play();
        }
}

function checkIfGameCharInContactWithEnemies(){
    if(checkIsGameOver()){
        return;
    }
    for (i in enemies){
        var enemy = enemies[i];
        var inContact = enemy.checkContact(gameChar_world_x,gameChar_y);
        if(inContact){
            hitByEnemy = true;
            lives--;
            break;
        }
    }
}

function checkIfGameCharOnPlatform(){
    if(isFalling){
        var isContact = false;
        onPlatform = false;
        for(i in platforms){
            var platform = platforms[i];
            isContact = platform.checkContact(gameChar_world_x,gameChar_y);
            
            if(isContact){
                onPlatform = true;
                break;
            }
        }
        if(isContact == false){
            gameChar_y += 1;
        }
    }
}

function checkFlagpole(){
    var d = dist(gameChar_world_x,gameChar_y, flagpole.pos_x, floorPos_y);
    if(flagpole.isReached==false){
        if(d<10  && game_score>=30){
           flagpole.isReached=true;
            winSound.play();
           }
        
    }
}

function checkIsGameOver(){
    var gameOver = false;
    
    if(flagpole.isReached || lives<1){
        gameOver = true;
    }
    return gameOver;
}

function checkPlayerDie(){
    if(gameChar_y>height){
        if(lives>0){
            startGame();
        }
    }
}