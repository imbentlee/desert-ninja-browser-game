var gameChar_x;
var gameChar_y;
var gameChar_width;

var floorPos_y;

var canyons;
var clouds;
var cactuses;
var mountains;
var coins;
var lifeTokens;

var isLeft;
var isRight;
var isFalling;
var isPlummeting;

var scrollPos;
var gameChar_world_x;

var game_score;

var flagpole;

var lives;

var emitters;

var platforms;
var onPlatform;

var enemies;
var hitByEnemy;

/*Sounds*/
var jumpSound;
var collectSound;
var fallSound;
var landSound;
var winSound;

function preload(){
    /*Sound Effects from https://mixkit.co/free-sound-effects*/
    soundFormats("mp3");
    jumpSound = loadSound("assets/jump.mp3");
    collectSound = loadSound("assets/collect.mp3");
    fallSound = loadSound("assets/fall.mp3");
    landSound = loadSound("assets/landing.mp3");
    winSound = loadSound("assets/win.mp3");
}

function setup()
{
	createCanvas(1024,576);
    
    startGame();
}
    
function startGame()
{
    floorPos_y = height * 3/4;
    
    lives = 2;
    
    //initialise the game
    gameChar_x = width/4;
	gameChar_y = floorPos_y;
    gameChar_width = 28;
    
    //initialise game_score to 0;
    game_score = 0;
    
    isLeft = false;
    isRight = false;
    isFalling = false;
    isPlummeting = false;
    onPlatform = false;
    hitByEnemy = false;
    
    scrollPos = 0;
    gameChar_world_x = gameChar_x;
    
    flagpole = {pos_x: 3600,
                pole_height: 200,
                flag_height: 50,
                flag_width: 90,
                isReached:false};
    
    clouds =[];
    initClouds();
    
    canyons = [];
    initCanyons();
    
    mountains = [];
    initMountains();
    
    cactuses = [];
    initCactuses();
    
    coins = [];
    initCoins();
    
    emitters = [];
    initFire();
    
    lifeTokens = [];
    initLifeTokens();
    
    platforms = [];
    initPlatforms();
    
    enemies = [];
    initEnemies();
}

function collectCoins(){
    for(var i=0;i<coins.length;i++){
        var coin = coins[i];
        collectCoin(coin);
    }
}
    
function collectCoin(coin)
{
    var d = dist(gameChar_world_x, gameChar_y, coin.pos_x, coin.pos_y);      //declare range
    if(coin.isFound==false){
        if(d<35){
            coin.isFound=true;                                        //will make coin disappear
            game_score++;                                            //increase game score
            collectSound.play();
        }
    }
}

function collectLifeTokens(){
    for(var i=0;i<lifeTokens.length;i++){
        var lifeToken = lifeTokens[i];
        collectLifeToken(lifeToken);
    }
}
    
function collectLifeToken(lifeToken){
    var d = dist(gameChar_world_x, gameChar_y, lifeToken.pos_x, lifeToken.pos_y);      //declare range
    if(lifeToken.isFound==false){
        if(d<35){
            lifeToken.isFound=true;                             //will make life token disappear
            lives++;                                            //increase lives
        }
    }
}

function draw()
{
	drawSky(); //fill the sky blue

	drawGround();
    
    push();                             //push
    translate(scrollPos,0);             //translate
    drawCanyons();
    drawMountains();
    drawCactuses();
    drawClouds();
    animateClouds();
    drawPlatforms();
    drawFire();
    drawCoins();
    drawLifeTokens();
    drawEnemies();
    drawFlagpole();
    pop();                              //pop back to origin
    
    drawGameScore();                    //add game score counter
    drawLifeCounter();
    
    drawGameChar();
    
    checkIfGameCharInContactWithEnemies();
    checkIfGameCharIsOverCanyons();     //check if character is completely over the canyon
    
    collectCoins();                     //check if coin is in range and collect it
    
    collectLifeTokens();
    
    checkFlagpole();
    
    var isGameOver = checkIsGameOver();
    if(isGameOver==true){
        drawGameOver();
        return;
    }
    
    if(hitByEnemy){
        if(lives>0){
            startGame();
        }
        return;
    }
    
    if(isPlummeting==true)
    {
        gameChar_y += 7;
        checkPlayerDie();
        return;
    }

    if(gameChar_y<floorPos_y){
        //gameChar_y += 1;
        isFalling = true;
    }else{
        isFalling = false;
    }

    if(isLeft==true){
        if(gameChar_x > width * 0.4)
        {
            gameChar_x -= 3;
        }
        else
        {
            scrollPos += 3;
        }
    }
    else if(isRight==true){
        if(gameChar_x < width * 0.6)
        {
            gameChar_x  += 3;
        }
        else
        {   //negative for moving against the background
            scrollPos -= 3; 
        }
    }
    checkIfGameCharOnPlatform();
    //Update real position of gameChar for collision detection.
    gameChar_world_x = gameChar_x - scrollPos;
}

function drawGameChar(){
    
    if(onPlatform && isLeft)
    {
        drawIsLeft();
    }
    if(onPlatform && isRight)
    {
        drawIsRight();
    }
    if(isLeft && isFalling)
    {
        drawIsLeftAndIsFalling();
    }
    else if(isRight && isFalling)
    {
        drawIsRightAndIsFalling();
    }
    else if(isLeft)
    {
        drawIsLeft();
    }
    else if(isRight)
    {
        drawIsRight();
    }
    else if(onPlatform)
    {
        drawStandingFront();    
    }
    else if(isFalling || isPlummeting)
    {
        drawIsFallingOrIsPlummeting();
    }
    else
    {
        drawStandingFront();
    }
}

function animateClouds(){
    for(i in clouds){
        var cloud = clouds[i];
        cloud.pos_x -= cloud.speed;
    }
}

///PRESS FUNCTIONS///
function keyPressed()
{
    console.log("keyPressed: " + key);
    console.log("keyPressed: " + keyCode);
    
    var isGameOver = checkIsGameOver();
    /*if(isGameOver == true){
        return;
    }*/
    
    if(keyCode == 37)           //left arrow key pressed
        {
            isLeft = true;
        }
    
    else if (keyCode == 39)     //right arrow key pressed
        {
            isRight = true;
        }
    
    else if (keyCode == 38)     //up arrow key
        {
            if(gameChar_y >= floorPos_y || onPlatform)
                {
                    gameChar_y -= 150;
                    jumpSound.play();
                }
        }
    else if (keyCode == 32)
        {
            if(isGameOver == true){
                setup();
                /*return;*/
            }
        }
}

function keyReleased()
{
    console.log("keyReleased: " + key);
    console.log("keyReleased: " + keyCode);
    
    var isGameOver = checkIsGameOver();
    /*if(isGameOver == true){
        return;
    }*/
    
    if(keyCode == 37)           //left arrow key released
        {
            isLeft = false;
        }
    
    else if (keyCode == 39)     //right arrow key released
        {
            isRight = false;
        }
}