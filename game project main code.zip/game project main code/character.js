function drawStandingFront()
{
    //body
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x, gameChar_y-46);
    vertex(gameChar_x-9, gameChar_y-40);
    vertex(gameChar_x-15, gameChar_y-23);
    vertex(gameChar_x-7, gameChar_y-33);
    vertex(gameChar_x-6, gameChar_y-22);
    vertex(gameChar_x-10, gameChar_y);
    vertex(gameChar_x, gameChar_y-15);
    vertex(gameChar_x+10, gameChar_y);
    vertex(gameChar_x+6, gameChar_y-22);
    vertex(gameChar_x+7, gameChar_y-33);
    vertex(gameChar_x+15, gameChar_y-23);
    vertex(gameChar_x+9, gameChar_y-40);
    vertex(gameChar_x, gameChar_y-46);
    endShape();
    
    //vest
    stroke(0);
    strokeWeight(0.5);
    fill(72,190,80);
    rect(gameChar_x-10, gameChar_y-44, 20, 30, 6, 6, 8, 8);
    fill(220);
    rect(gameChar_x-1, gameChar_y-44, 2, 30);
    
    //head
    stroke(0);
    strokeWeight(0.5);
    fill(255,230,175);
    ellipse(gameChar_x, gameChar_y-55, 15, 20);
    
    //face
    stroke(0);
    strokeWeight(0.5);
    noFill();
    arc(gameChar_x-3, gameChar_y-54, 2, 2, PI, TWO_PI);
    arc(gameChar_x+3, gameChar_y-54, 2, 2, PI, TWO_PI);
    arc(gameChar_x, gameChar_y-49, 3, 2, 0, PI);
    
    //hair
    noStroke();
    fill(0);
    beginShape();
    vertex(gameChar_x-8, gameChar_y-61);
    vertex(gameChar_x-9, gameChar_y-68);
    vertex(gameChar_x-6, gameChar_y-67);
    vertex(gameChar_x-3, gameChar_y-70);
    vertex(gameChar_x, gameChar_y-68);
    vertex(gameChar_x+3, gameChar_y-70);
    vertex(gameChar_x+6, gameChar_y-67);
    vertex(gameChar_x+9, gameChar_y-68);
    vertex(gameChar_x+8, gameChar_y-61);
    endShape();
    
    //headband
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    rect(gameChar_x-9, gameChar_y-63,18,6,5,5,5,5);
    fill(200);
    rect(gameChar_x-4, gameChar_y-62,8,4,5,5,5,5);
}

function drawIsFallingOrIsPlummeting()
{
    //body
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x, gameChar_y-44);
    vertex(gameChar_x-22, gameChar_y-28);
    vertex(gameChar_x-8, gameChar_y-32);
    vertex(gameChar_x-7, gameChar_y-20);
    vertex(gameChar_x-14, gameChar_y);
    vertex(gameChar_x, gameChar_y-15);
    vertex(gameChar_x+14, gameChar_y);
    vertex(gameChar_x+7, gameChar_y-20);
    vertex(gameChar_x+8, gameChar_y-32);
    vertex(gameChar_x+22, gameChar_y-28);
    vertex(gameChar_x, gameChar_y-44);
    endShape();
    
    //vest
    stroke(0);
    strokeWeight(0.5);
    fill(72,190,80);
    rect(gameChar_x-10, gameChar_y-42, 20, 30, 6, 6, 8, 8);
    fill(220);
    rect(gameChar_x-1, gameChar_y-42, 2, 30);
    
    //head
    stroke(0);
    strokeWeight(0.5);
    fill(255,230,175);
    ellipse(gameChar_x, gameChar_y-53, 15, 20);
    
    //face
    stroke(0);
    strokeWeight(0.5);
    fill(255);
    ellipse(gameChar_x-3, gameChar_y-52, 2, 2);
    ellipse(gameChar_x+3, gameChar_y-52, 2, 2);
    stroke(0);
    strokeWeight(0.5);
    fill(0);
    ellipse(gameChar_x, gameChar_y-47, 2, 3);
    
    //hair
    noStroke();
    fill(0);
    beginShape();
    vertex(gameChar_x-8, gameChar_y-59);
    vertex(gameChar_x-9, gameChar_y-66);
    vertex(gameChar_x-6, gameChar_y-65);
    vertex(gameChar_x-3, gameChar_y-68);
    vertex(gameChar_x, gameChar_y-66);
    vertex(gameChar_x+3, gameChar_y-68);
    vertex(gameChar_x+6, gameChar_y-65);
    vertex(gameChar_x+9, gameChar_y-66);
    vertex(gameChar_x+8, gameChar_y-59);
    endShape();
    
    //headband
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    rect(gameChar_x-9, gameChar_y-61,18,6,5,5,5,5);
    stroke(0);
    strokeWeight(0.5);
    fill(200);
    rect(gameChar_x-4, gameChar_y-60,8,4,5,5,5,5);
}

function drawIsLeft()
{
    //body
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x+1, gameChar_y-43);
    vertex(gameChar_x+6, gameChar_y-17);
    vertex(gameChar_x+18, gameChar_y);
    vertex(gameChar_x, gameChar_y-15);
    vertex(gameChar_x-7, gameChar_y-10);
    vertex(gameChar_x-5, gameChar_y);
    vertex(gameChar_x-12, gameChar_y-11);
    vertex(gameChar_x-6, gameChar_y-17);
    vertex(gameChar_x-1, gameChar_y-43);
    endShape();
    
    //vest
    stroke(0);
    strokeWeight(0.5);
    fill(72,190,80);
    rect(gameChar_x-8, gameChar_y-41, 16, 30, 6, 6, 8, 8);
    
    //arm
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x, gameChar_y-36);
    vertex(gameChar_x+18, gameChar_y-27);
    vertex(gameChar_x, gameChar_y-30);
    endShape();
    fill(255,0,0);
    ellipse(gameChar_x+3, gameChar_y-32, 3, 3);
    
    //head
    stroke(0);
    strokeWeight(0.5);
    fill(255,230,175);
    ellipse(gameChar_x, gameChar_y-52, 15, 20);
    
    //face
    stroke(0);
    strokeWeight(0.5);
    noFill();
    arc(gameChar_x-5, gameChar_y-51, 2, 2, PI, TWO_PI);
    arc(gameChar_x-5, gameChar_y-46, 3, 2, 0, HALF_PI);
    
    //hair
    noStroke();
    fill(0);
    beginShape();
    vertex(gameChar_x-8, gameChar_y-58);
    vertex(gameChar_x-9, gameChar_y-65);
    vertex(gameChar_x-6, gameChar_y-64);
    vertex(gameChar_x-3, gameChar_y-67);
    vertex(gameChar_x, gameChar_y-65);
    vertex(gameChar_x+3, gameChar_y-67);
    vertex(gameChar_x+6, gameChar_y-64);
    vertex(gameChar_x+9, gameChar_y-65);
    vertex(gameChar_x+8, gameChar_y-58);
    endShape();
    
    //headband
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    rect(gameChar_x-9, gameChar_y-60,18,6,5,5,5,5);
}

function drawIsRight()
{
    //body
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x-1, gameChar_y-43);
    vertex(gameChar_x-6, gameChar_y-17);
    vertex(gameChar_x-18, gameChar_y);
    vertex(gameChar_x, gameChar_y-15);
    vertex(gameChar_x+7, gameChar_y-10);
    vertex(gameChar_x+5, gameChar_y);
    vertex(gameChar_x+12, gameChar_y-11);
    vertex(gameChar_x+6, gameChar_y-17);
    vertex(gameChar_x+1, gameChar_y-43);
    endShape();
    
    //vest
    stroke(0);
    strokeWeight(0.5);
    fill(72,190,80);
    rect(gameChar_x-8, gameChar_y-41, 16, 30, 6, 6, 8, 8);
    
    //arm
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x, gameChar_y-36);
    vertex(gameChar_x-18, gameChar_y-27);
    vertex(gameChar_x, gameChar_y-30);
    endShape();
    fill(255,0,0);
    ellipse(gameChar_x-3, gameChar_y-32, 3, 3);
    
    //head
    stroke(0);
    strokeWeight(0.5);
    fill(255,230,175);
    ellipse(gameChar_x, gameChar_y-52, 15, 20);
    
    //face
    stroke(0);
    strokeWeight(0.5);
    noFill();
    arc(gameChar_x+5, gameChar_y-51, 2, 2, PI, TWO_PI);
    arc(gameChar_x+5, gameChar_y-46, 3, 2, HALF_PI, PI);
    
    //hair
    noStroke();
    fill(0);
    beginShape();
    vertex(gameChar_x-8, gameChar_y-58);
    vertex(gameChar_x-9, gameChar_y-65);
    vertex(gameChar_x-6, gameChar_y-64);
    vertex(gameChar_x-3, gameChar_y-67);
    vertex(gameChar_x, gameChar_y-65);
    vertex(gameChar_x+3, gameChar_y-67);
    vertex(gameChar_x+6, gameChar_y-64);
    vertex(gameChar_x+9, gameChar_y-65);
    vertex(gameChar_x+8, gameChar_y-58);
    endShape();
    
    //headband
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    rect(gameChar_x-9, gameChar_y-60,18,6,5,5,5,5);
}

function drawIsRightAndIsFalling()
{
    //body
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x-1, gameChar_y-41);
    vertex(gameChar_x-6, gameChar_y-15);
    vertex(gameChar_x-20, gameChar_y);
    vertex(gameChar_x, gameChar_y-13);
    vertex(gameChar_x+7, gameChar_y-8);
    vertex(gameChar_x+3, gameChar_y);
    vertex(gameChar_x+12, gameChar_y-9);
    vertex(gameChar_x+6, gameChar_y-15);
    vertex(gameChar_x+1, gameChar_y-41);
    endShape();
    
    //vest
    stroke(0);
    strokeWeight(0.5);
    fill(72,190,80);
    rect(gameChar_x-8, gameChar_y-39, 16, 30, 6, 6, 8, 8);
    
    //arm
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x, gameChar_y-34);
    vertex(gameChar_x-18, gameChar_y-25);
    vertex(gameChar_x, gameChar_y-28);
    endShape();
    fill(255,0,0);
    ellipse(gameChar_x-3, gameChar_y-30, 3, 3);
    
    //head
    stroke(0);
    strokeWeight(0.5);
    fill(255,230,175);
    ellipse(gameChar_x, gameChar_y-50, 15, 20);
    
    //face
    stroke(0);
    strokeWeight(0.5);
    fill(255);
    ellipse(gameChar_x+5, gameChar_y-49, 2, 2);
    stroke(0);
    strokeWeight(0.5);
    fill(0);
    ellipse(gameChar_x+4, gameChar_y-44, 3, 2);
    
    //hair
    noStroke();
    fill(0);
    beginShape();
    vertex(gameChar_x-8, gameChar_y-56);
    vertex(gameChar_x-9, gameChar_y-63);
    vertex(gameChar_x-6, gameChar_y-62);
    vertex(gameChar_x-3, gameChar_y-65);
    vertex(gameChar_x, gameChar_y-63);
    vertex(gameChar_x+3, gameChar_y-65);
    vertex(gameChar_x+6, gameChar_y-62);
    vertex(gameChar_x+9, gameChar_y-63);
    vertex(gameChar_x+8, gameChar_y-56);
    endShape();
    
    //headband
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    rect(gameChar_x-9, gameChar_y-58,18,6,5,5,5,5);
}

function drawIsLeftAndIsFalling()
{
    //body
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x+1, gameChar_y-41);
    vertex(gameChar_x+6, gameChar_y-15);
    vertex(gameChar_x+20, gameChar_y);
    vertex(gameChar_x, gameChar_y-13);
    vertex(gameChar_x-7, gameChar_y-8);
    vertex(gameChar_x-3, gameChar_y);
    vertex(gameChar_x-12, gameChar_y-9);
    vertex(gameChar_x-6, gameChar_y-15);
    vertex(gameChar_x-1, gameChar_y-41);
    endShape();
    
    //vest
    stroke(0);
    strokeWeight(0.5);
    fill(72,190,80);
    rect(gameChar_x-8, gameChar_y-39, 16, 30, 6, 6, 8, 8);
    
    //arm
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    beginShape();
    vertex(gameChar_x, gameChar_y-34);
    vertex(gameChar_x+18, gameChar_y-25);
    vertex(gameChar_x, gameChar_y-28);
    endShape();
    fill(255,0,0);
    ellipse(gameChar_x+3, gameChar_y-30, 3, 3);
    
    //head
    stroke(0);
    strokeWeight(0.5);
    fill(255,230,175);
    ellipse(gameChar_x, gameChar_y-50, 15, 20);
    
    //face
    stroke(0);
    strokeWeight(0.5);
    fill(255);
    ellipse(gameChar_x-5, gameChar_y-49, 2, 2);
    stroke(0);
    strokeWeight(0.5);
    fill(0);
    ellipse(gameChar_x-4, gameChar_y-44, 3, 2);
    
    //hair
    noStroke();
    fill(0);
    beginShape();
    vertex(gameChar_x-8, gameChar_y-56);
    vertex(gameChar_x-9, gameChar_y-63);
    vertex(gameChar_x-6, gameChar_y-62);
    vertex(gameChar_x-3, gameChar_y-65);
    vertex(gameChar_x, gameChar_y-63);
    vertex(gameChar_x+3, gameChar_y-65);
    vertex(gameChar_x+6, gameChar_y-62);
    vertex(gameChar_x+9, gameChar_y-63);
    vertex(gameChar_x+8, gameChar_y-56);
    endShape();
    
    //headband
    stroke(0);
    strokeWeight(0.5);
    fill(0,15,80);
    rect(gameChar_x-9, gameChar_y-58,18,6,5,5,5,5);

}